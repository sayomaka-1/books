export const BooksData = [{
    "id" : 0,
    "name": "To be or not to be",
    "description": "Book by Shakesphere",
    "bookImgUrl": "",
    "startDate": 1549472478065,
    "totalPages": 100,
    "progress": [
        {
            "startPage": 0,
            "endPage": 10,
            "date": 1549299678065
        },
        {
            "startPage": 10,
            "endPage": 20,
            "date": 1549213278065
        }
    ]
},
{
    "id" : 1,
    "name": "collective intelligence",
    "description": "Book on Machine Learning",
    "bookImgUrl": "",
    "startDate": 1547485278065,
    "totalPages": 200,
    "progress": [
        {
            "startPage": 0,
            "endPage": 30,
            "date": 1544288478065
        },
        {
            "startPage": 30,
            "endPage": 50,
            "date": 1542733278065
        }
    ]
}]