export class Progress{
    public  startPage: Number;
    public endPage: Number;
    public date: Number;
}