import { Progress } from './progress.model';
export class Book {
    public name: string;
    public description: string;
    public bookImgUrl: string;
    public startDate: number;
    public totalPages: number;
    public Progress: any;


    constructor(name: string, desc: string, url: string, start: number, pages: number, prog: any) { 
        this.name = name;
        this.description = desc;
        this.bookImgUrl = url;
        this.startDate = start;
        this.totalPages = pages;
        this.Progress = prog;
    }
}