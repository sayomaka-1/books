import { Component, OnInit } from '@angular/core';
import { BooksData } from './../shared/data/books.data';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  // @TO-DO add the type
  books = BooksData;

  constructor() {
    for (var x = 0; x < this.books.length; x++) {
      var d = new Date(this.books[x].startDate);
      this.books[x].dateFormat = d.toLocaleDateString()
      for (var y = 0; y < this.books[x].progress.length; y++) {
        this.books[x].PagesComplete = 0;
        if (this.books[x].progress[y].endPage > this.books[x].PagesComplete) {
          this.books[x].PagesComplete = this.books[x].progress[y].endPage;
        }
      }
    }
    console.log(this.books)
  }

  ngOnInit() {

  }




}
